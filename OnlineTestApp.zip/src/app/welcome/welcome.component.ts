import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  @ViewChild('name') nameKey!: ElementRef
  constructor() { }

  ngOnInit(): void {

  }

  startQuiz(welcomeForm: any) {
    console.log("Form Submitted!", welcomeForm)
    localStorage.setItem('name', welcomeForm.form.controls['name'].value)
  }
}
